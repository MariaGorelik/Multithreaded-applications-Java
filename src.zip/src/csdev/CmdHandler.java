package csdev;


public interface CmdHandler {
	boolean onCommand( int[] errorCode );
}

